The password is 1234.
Don't use too big numbers because stoi function will not work.
The name of some files is seed_shop. It should be seyed shop but I had a typo while creating files in qt creator.I'm sorry about that!
This application is made with Windows 32-bit compiler, as a result, users of other operating systems may have some problems while running it, especially when creating directories.
Thanks for reading
Ali Karimi