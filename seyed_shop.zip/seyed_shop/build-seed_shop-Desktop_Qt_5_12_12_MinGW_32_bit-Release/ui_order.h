/********************************************************************************
** Form generated from reading UI file 'order.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ORDER_H
#define UI_ORDER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_order
{
public:
    QPushButton *order_ok;
    QLabel *label;
    QListWidget *products_list;

    void setupUi(QDialog *order)
    {
        if (order->objectName().isEmpty())
            order->setObjectName(QString::fromUtf8("order"));
        order->resize(400, 300);
        order->setMinimumSize(QSize(400, 300));
        order->setMaximumSize(QSize(400, 300));
        order->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(11, 88, 111, 255), stop:1 rgba(255, 255, 255, 255));"));
        order_ok = new QPushButton(order);
        order_ok->setObjectName(QString::fromUtf8("order_ok"));
        order_ok->setGeometry(QRect(150, 260, 101, 31));
        order_ok->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0.357955 rgba(0, 0, 99, 255), stop:1 rgba(0, 0, 129, 255));\n"
"border-color: black;\n"
"border-radius: 10px;\n"
"color: rgb(255, 255, 255);\n"
"font: 75 10pt \"B Nasim\";"));
        label = new QLabel(order);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 10, 361, 51));
        label->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 0, 0, 0), stop:1 rgba(255, 255, 255, 255));"));
        products_list = new QListWidget(order);
        products_list->setObjectName(QString::fromUtf8("products_list"));
        products_list->setGeometry(QRect(20, 70, 361, 181));
        products_list->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 0, 0, 0), stop:1 rgba(255, 255, 255, 255));\n"
""));

        retranslateUi(order);

        QMetaObject::connectSlotsByName(order);
    } // setupUi

    void retranslateUi(QDialog *order)
    {
        order->setWindowTitle(QApplication::translate("order", "Order", nullptr));
#ifndef QT_NO_TOOLTIP
        order_ok->setToolTip(QApplication::translate("order", "<html><head/><body><p>editing the product</p></body></html>", nullptr));
#endif // QT_NO_TOOLTIP
        order_ok->setText(QApplication::translate("order", "OK", nullptr));
        label->setText(QApplication::translate("order", "<html><head/><body><p align=\"center\"><span style=\" font-size:10pt; font-weight:600;\">Warning: first click on the row that you want, </span></p><p align=\"center\"><span style=\" font-size:10pt; font-weight:600;\">then press the button.</span></p></body></html>", nullptr));
#ifndef QT_NO_TOOLTIP
        products_list->setToolTip(QApplication::translate("order", "<html><head/><body><p>click to select item</p></body></html>", nullptr));
#endif // QT_NO_TOOLTIP
    } // retranslateUi

};

namespace Ui {
    class order: public Ui_order {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ORDER_H
