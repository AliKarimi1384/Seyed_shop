/********************************************************************************
** Form generated from reading UI file 'first_page.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FIRST_PAGE_H
#define UI_FIRST_PAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>

QT_BEGIN_NAMESPACE

class Ui_first_page
{
public:
    QLabel *label;
    QLabel *label_2;
    QSpinBox *pass_1;
    QSpinBox *pass_2;
    QSpinBox *pass_3;
    QSpinBox *pass_4;
    QPushButton *enter_pass;

    void setupUi(QDialog *first_page)
    {
        if (first_page->objectName().isEmpty())
            first_page->setObjectName(QString::fromUtf8("first_page"));
        first_page->resize(298, 217);
        first_page->setMinimumSize(QSize(298, 217));
        first_page->setMaximumSize(QSize(298, 217));
        first_page->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(11, 88, 111, 255), stop:1 rgba(255, 255, 255, 255));"));
        label = new QLabel(first_page);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(120, 20, 51, 16));
        label->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 0));"));
        label_2 = new QLabel(first_page);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(50, 50, 191, 41));
        label_2->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 0));"));
        pass_1 = new QSpinBox(first_page);
        pass_1->setObjectName(QString::fromUtf8("pass_1"));
        pass_1->setGeometry(QRect(40, 120, 42, 22));
        pass_1->setMaximum(9);
        pass_2 = new QSpinBox(first_page);
        pass_2->setObjectName(QString::fromUtf8("pass_2"));
        pass_2->setGeometry(QRect(100, 120, 42, 22));
        pass_2->setMaximum(9);
        pass_3 = new QSpinBox(first_page);
        pass_3->setObjectName(QString::fromUtf8("pass_3"));
        pass_3->setGeometry(QRect(160, 120, 42, 22));
        pass_3->setMaximum(9);
        pass_4 = new QSpinBox(first_page);
        pass_4->setObjectName(QString::fromUtf8("pass_4"));
        pass_4->setGeometry(QRect(220, 120, 42, 22));
        pass_4->setMaximum(9);
        enter_pass = new QPushButton(first_page);
        enter_pass->setObjectName(QString::fromUtf8("enter_pass"));
        enter_pass->setGeometry(QRect(100, 170, 101, 31));
        enter_pass->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0.357955 rgba(0, 0, 99, 255), stop:1 rgba(0, 0, 129, 255));\n"
"border-color: black;\n"
"border-radius: 10px;\n"
"color: rgb(255, 255, 255);\n"
"font: 75 10pt \"B Nasim\";"));

        retranslateUi(first_page);

        QMetaObject::connectSlotsByName(first_page);
    } // setupUi

    void retranslateUi(QDialog *first_page)
    {
        first_page->setWindowTitle(QApplication::translate("first_page", "First page", nullptr));
        label->setText(QApplication::translate("first_page", "<html><head/><body><p align=\"center\"><span style=\" font-size:10pt; font-weight:600;\">Hello!</span></p></body></html>", nullptr));
        label_2->setText(QApplication::translate("first_page", "<html><head/><body><p align=\"center\"><span style=\" font-size:10pt; font-weight:600;\">Please enter the password.</span></p></body></html>", nullptr));
#ifndef QT_NO_TOOLTIP
        enter_pass->setToolTip(QApplication::translate("first_page", "<html><head/><body><p>Enter password</p></body></html>", nullptr));
#endif // QT_NO_TOOLTIP
        enter_pass->setText(QApplication::translate("first_page", "Enter", nullptr));
    } // retranslateUi

};

namespace Ui {
    class first_page: public Ui_first_page {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FIRST_PAGE_H
