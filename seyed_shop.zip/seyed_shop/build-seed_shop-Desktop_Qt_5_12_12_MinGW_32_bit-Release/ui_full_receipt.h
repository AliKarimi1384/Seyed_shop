/********************************************************************************
** Form generated from reading UI file 'full_receipt.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FULL_RECEIPT_H
#define UI_FULL_RECEIPT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_full_receipt
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *date_and_time;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *customer_name;
    QLabel *product_name;
    QLabel *product_price;
    QLabel *product_count;
    QLabel *off_percentage;
    QLabel *label_17;
    QLabel *tax_amount;
    QLabel *final_price;
    QPushButton *print_receipt;

    void setupUi(QDialog *full_receipt)
    {
        if (full_receipt->objectName().isEmpty())
            full_receipt->setObjectName(QString::fromUtf8("full_receipt"));
        full_receipt->resize(400, 466);
        full_receipt->setMinimumSize(QSize(400, 466));
        full_receipt->setMaximumSize(QSize(400, 466));
        full_receipt->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(11, 88, 111, 255), stop:1 rgba(255, 255, 255, 255));"));
        label = new QLabel(full_receipt);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(90, 20, 221, 31));
        label->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 0, 0, 0), stop:1 rgba(255, 255, 255, 255));\n"
"border-radius:10px;"));
        label_2 = new QLabel(full_receipt);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(50, 80, 111, 16));
        label_2->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 0));"));
        date_and_time = new QLabel(full_receipt);
        date_and_time->setObjectName(QString::fromUtf8("date_and_time"));
        date_and_time->setGeometry(QRect(200, 80, 161, 16));
        date_and_time->setStyleSheet(QString::fromUtf8("font: 75 10pt \"MS Shell Dlg 2\";\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 0, 0, 0), stop:1 rgba(255, 255, 255, 255));\n"
"border-radius: 10px;"));
        label_4 = new QLabel(full_receipt);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(50, 120, 111, 16));
        label_4->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 0));"));
        label_5 = new QLabel(full_receipt);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(50, 160, 111, 16));
        label_5->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 0));"));
        label_6 = new QLabel(full_receipt);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(50, 200, 111, 16));
        label_6->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 0));"));
        label_7 = new QLabel(full_receipt);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(50, 240, 111, 16));
        label_7->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 0));"));
        label_8 = new QLabel(full_receipt);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(50, 280, 111, 16));
        label_8->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 0));"));
        label_9 = new QLabel(full_receipt);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(50, 320, 111, 16));
        label_9->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 0));"));
        label_10 = new QLabel(full_receipt);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(50, 360, 111, 16));
        label_10->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 0));"));
        label_11 = new QLabel(full_receipt);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(50, 400, 111, 16));
        label_11->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 0));"));
        customer_name = new QLabel(full_receipt);
        customer_name->setObjectName(QString::fromUtf8("customer_name"));
        customer_name->setGeometry(QRect(230, 120, 131, 16));
        customer_name->setStyleSheet(QString::fromUtf8("font: 75 10pt \"MS Shell Dlg 2\";\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 0, 0, 0), stop:1 rgba(255, 255, 255, 255));\n"
"border-radius: 10px;"));
        product_name = new QLabel(full_receipt);
        product_name->setObjectName(QString::fromUtf8("product_name"));
        product_name->setGeometry(QRect(230, 160, 131, 16));
        product_name->setStyleSheet(QString::fromUtf8("font: 75 10pt \"MS Shell Dlg 2\";\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 0, 0, 0), stop:1 rgba(255, 255, 255, 255));\n"
"border-radius: 10px;"));
        product_price = new QLabel(full_receipt);
        product_price->setObjectName(QString::fromUtf8("product_price"));
        product_price->setGeometry(QRect(230, 200, 131, 16));
        product_price->setStyleSheet(QString::fromUtf8("font: 75 10pt \"MS Shell Dlg 2\";\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 0, 0, 0), stop:1 rgba(255, 255, 255, 255));\n"
"border-radius: 10px;"));
        product_count = new QLabel(full_receipt);
        product_count->setObjectName(QString::fromUtf8("product_count"));
        product_count->setGeometry(QRect(230, 240, 131, 16));
        product_count->setStyleSheet(QString::fromUtf8("font: 75 10pt \"MS Shell Dlg 2\";\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 0, 0, 0), stop:1 rgba(255, 255, 255, 255));\n"
"border-radius: 10px;"));
        off_percentage = new QLabel(full_receipt);
        off_percentage->setObjectName(QString::fromUtf8("off_percentage"));
        off_percentage->setGeometry(QRect(230, 280, 131, 16));
        off_percentage->setStyleSheet(QString::fromUtf8("font: 75 10pt \"MS Shell Dlg 2\";\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 0, 0, 0), stop:1 rgba(255, 255, 255, 255));\n"
"border-radius: 10px;"));
        label_17 = new QLabel(full_receipt);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setGeometry(QRect(230, 320, 131, 16));
        label_17->setStyleSheet(QString::fromUtf8("font: 75 10pt \"MS Shell Dlg 2\";\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 0, 0, 0), stop:1 rgba(255, 255, 255, 255));\n"
"border-radius: 10px;"));
        tax_amount = new QLabel(full_receipt);
        tax_amount->setObjectName(QString::fromUtf8("tax_amount"));
        tax_amount->setGeometry(QRect(230, 360, 131, 16));
        tax_amount->setStyleSheet(QString::fromUtf8("font: 75 10pt \"MS Shell Dlg 2\";\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 0, 0, 0), stop:1 rgba(255, 255, 255, 255));\n"
"border-radius: 10px;"));
        final_price = new QLabel(full_receipt);
        final_price->setObjectName(QString::fromUtf8("final_price"));
        final_price->setGeometry(QRect(230, 400, 131, 16));
        final_price->setStyleSheet(QString::fromUtf8("font: 75 10pt \"MS Shell Dlg 2\";\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(0, 0, 0, 0), stop:1 rgba(255, 255, 255, 255));\n"
"border-radius: 10px;"));
        print_receipt = new QPushButton(full_receipt);
        print_receipt->setObjectName(QString::fromUtf8("print_receipt"));
        print_receipt->setGeometry(QRect(140, 430, 101, 31));
        print_receipt->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:1 rgba(214, 0, 0, 255));\n"
"border-color: black;\n"
"border-radius: 10px;\n"
"color: rgb(255, 255, 255);\n"
"font: 75 10pt \"B Nasim\";"));

        retranslateUi(full_receipt);

        QMetaObject::connectSlotsByName(full_receipt);
    } // setupUi

    void retranslateUi(QDialog *full_receipt)
    {
        full_receipt->setWindowTitle(QApplication::translate("full_receipt", "Full receipt", nullptr));
        label->setText(QApplication::translate("full_receipt", "<html><head/><body><p align=\"center\"><span style=\" font-size:10pt; font-weight:600;\">Seyed shop receipt</span></p></body></html>", nullptr));
        label_2->setText(QApplication::translate("full_receipt", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:600;\">date and time:</span></p></body></html>", nullptr));
        date_and_time->setText(QApplication::translate("full_receipt", "TextLabel", nullptr));
        label_4->setText(QApplication::translate("full_receipt", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:600;\">customer name:</span></p></body></html>", nullptr));
        label_5->setText(QApplication::translate("full_receipt", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:600;\">product name:</span></p></body></html>", nullptr));
        label_6->setText(QApplication::translate("full_receipt", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:600;\">product price:</span></p></body></html>", nullptr));
        label_7->setText(QApplication::translate("full_receipt", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:600;\">product count:</span></p></body></html>", nullptr));
        label_8->setText(QApplication::translate("full_receipt", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:600;\">off percentage:</span></p></body></html>", nullptr));
        label_9->setText(QApplication::translate("full_receipt", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:600;\">tax rate:</span></p></body></html>", nullptr));
        label_10->setText(QApplication::translate("full_receipt", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:600;\">tax amount:</span></p></body></html>", nullptr));
        label_11->setText(QApplication::translate("full_receipt", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:600;\">final price:</span></p></body></html>", nullptr));
        customer_name->setText(QApplication::translate("full_receipt", "TextLabel", nullptr));
        product_name->setText(QApplication::translate("full_receipt", "TextLabel", nullptr));
        product_price->setText(QApplication::translate("full_receipt", "TextLabel", nullptr));
        product_count->setText(QApplication::translate("full_receipt", "TextLabel", nullptr));
        off_percentage->setText(QApplication::translate("full_receipt", "TextLabel", nullptr));
        label_17->setText(QApplication::translate("full_receipt", "<html><head/><body><p>10 %</p></body></html>", nullptr));
        tax_amount->setText(QApplication::translate("full_receipt", "TextLabel", nullptr));
        final_price->setText(QApplication::translate("full_receipt", "TextLabel", nullptr));
#ifndef QT_NO_TOOLTIP
        print_receipt->setToolTip(QApplication::translate("full_receipt", "<html><head/><body><p>printing the receipt</p></body></html>", nullptr));
#endif // QT_NO_TOOLTIP
        print_receipt->setText(QApplication::translate("full_receipt", "print receipt", nullptr));
    } // retranslateUi

};

namespace Ui {
    class full_receipt: public Ui_full_receipt {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FULL_RECEIPT_H
