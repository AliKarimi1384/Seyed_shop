/********************************************************************************
** Form generated from reading UI file 'add_product_.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADD_PRODUCT__H
#define UI_ADD_PRODUCT__H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>

QT_BEGIN_NAMESPACE

class Ui_Add_Product_
{
public:
    QPushButton *pushButton;
    QLabel *label;
    QPlainTextEdit *product_name_input;
    QLabel *label_2;
    QPlainTextEdit *product_price_input;
    QLabel *label_3;
    QSpinBox *off_percentage;
    QLabel *label_4;
    QSpinBox *product_number;

    void setupUi(QDialog *Add_Product_)
    {
        if (Add_Product_->objectName().isEmpty())
            Add_Product_->setObjectName(QString::fromUtf8("Add_Product_"));
        Add_Product_->resize(534, 294);
        Add_Product_->setMinimumSize(QSize(534, 294));
        Add_Product_->setMaximumSize(QSize(534, 294));
        Add_Product_->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(11, 88, 111, 255), stop:1 rgba(255, 255, 255, 255));"));
        pushButton = new QPushButton(Add_Product_);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(200, 230, 101, 31));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0.357955 rgba(0, 0, 99, 255), stop:1 rgba(0, 0, 129, 255));\n"
"border-color: black;\n"
"border-radius: 10px;\n"
"color: rgb(255, 255, 255);\n"
"font: 75 10pt \"B Nasim\";"));
        label = new QLabel(Add_Product_);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(130, 40, 99, 29));
        label->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 0));"));
        product_name_input = new QPlainTextEdit(Add_Product_);
        product_name_input->setObjectName(QString::fromUtf8("product_name_input"));
        product_name_input->setGeometry(QRect(240, 40, 181, 31));
        product_name_input->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 97), stop:1 rgba(255, 255, 255, 255));"));
        label_2 = new QLabel(Add_Product_);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(130, 80, 96, 29));
        label_2->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 0));"));
        product_price_input = new QPlainTextEdit(Add_Product_);
        product_price_input->setObjectName(QString::fromUtf8("product_price_input"));
        product_price_input->setGeometry(QRect(240, 80, 101, 31));
        product_price_input->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 97), stop:1 rgba(255, 255, 255, 255));"));
        label_3 = new QLabel(Add_Product_);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(130, 130, 111, 21));
        label_3->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 0));"));
        off_percentage = new QSpinBox(Add_Product_);
        off_percentage->setObjectName(QString::fromUtf8("off_percentage"));
        off_percentage->setGeometry(QRect(250, 160, 41, 18));
        label_4 = new QLabel(Add_Product_);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(130, 160, 111, 21));
        label_4->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 0));"));
        product_number = new QSpinBox(Add_Product_);
        product_number->setObjectName(QString::fromUtf8("product_number"));
        product_number->setGeometry(QRect(250, 130, 41, 18));
        product_number->setMinimum(1);
        product_number->setSingleStep(1);

        retranslateUi(Add_Product_);

        QMetaObject::connectSlotsByName(Add_Product_);
    } // setupUi

    void retranslateUi(QDialog *Add_Product_)
    {
        Add_Product_->setWindowTitle(QApplication::translate("Add_Product_", "Add Products", nullptr));
#ifndef QT_NO_TOOLTIP
        Add_Product_->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        pushButton->setText(QApplication::translate("Add_Product_", "OK", nullptr));
        label->setText(QApplication::translate("Add_Product_", "<html><head/><body><p align=\"center\"><span style=\" font-size:10pt; font-weight:600;\">product name: </span></p></body></html>", nullptr));
        product_name_input->setPlainText(QApplication::translate("Add_Product_", "product name", nullptr));
        label_2->setText(QApplication::translate("Add_Product_", "<html><head/><body><p align=\"center\"><span style=\" font-size:10pt; font-weight:600;\">product price:  </span></p></body></html>", nullptr));
        product_price_input->setPlainText(QApplication::translate("Add_Product_", "0", nullptr));
        label_3->setText(QApplication::translate("Add_Product_", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:600;\">product number: </span></p></body></html>", nullptr));
        label_4->setText(QApplication::translate("Add_Product_", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:600;\">off_percentage: </span></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Add_Product_: public Ui_Add_Product_ {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADD_PRODUCT__H
