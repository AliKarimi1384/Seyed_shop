/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *Add_Product;
    QPushButton *Products;
    QPushButton *Order;
    QPushButton *Orders;
    QTextBrowser *textBrowser;
    QPushButton *Turnover;
    QPushButton *About_us;
    QMenuBar *menubar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(753, 372);
        MainWindow->setMinimumSize(QSize(753, 372));
        MainWindow->setMaximumSize(QSize(753, 372));
        MainWindow->setCursor(QCursor(Qt::PointingHandCursor));
        MainWindow->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(11, 88, 111, 255), stop:1 rgba(255, 255, 255, 255));"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        Add_Product = new QPushButton(centralwidget);
        Add_Product->setObjectName(QString::fromUtf8("Add_Product"));
        Add_Product->setGeometry(QRect(90, 130, 121, 41));
        Add_Product->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0.357955 rgba(0, 0, 99, 255), stop:1 rgba(0, 0, 129, 255));\n"
"border-color: black;\n"
"border-radius: 10px;\n"
"color: rgb(255, 255, 255);\n"
"font: 75 10pt \"B Nasim\";"));
        Products = new QPushButton(centralwidget);
        Products->setObjectName(QString::fromUtf8("Products"));
        Products->setGeometry(QRect(310, 130, 121, 41));
        Products->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0.357955 rgba(0, 0, 99, 255), stop:1 rgba(0, 0, 129, 255));\n"
"border-color: black;\n"
"border-radius: 10px;\n"
"color: rgb(255, 255, 255);\n"
"font: 75 10pt \"B Nasim\";"));
        Order = new QPushButton(centralwidget);
        Order->setObjectName(QString::fromUtf8("Order"));
        Order->setGeometry(QRect(530, 130, 121, 41));
        Order->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0.357955 rgba(0, 0, 99, 255), stop:1 rgba(0, 0, 129, 255));\n"
"border-color: black;\n"
"border-radius: 10px;\n"
"color: rgb(255, 255, 255);\n"
"font: 75 10pt \"B Nasim\";"));
        Orders = new QPushButton(centralwidget);
        Orders->setObjectName(QString::fromUtf8("Orders"));
        Orders->setGeometry(QRect(90, 240, 121, 41));
        Orders->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0.357955 rgba(0, 0, 99, 255), stop:1 rgba(0, 0, 129, 255));\n"
"border-color: black;\n"
"border-radius: 10px;\n"
"color: rgb(255, 255, 255);\n"
"font: 75 10pt \"B Nasim\";"));
        textBrowser = new QTextBrowser(centralwidget);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(210, 20, 311, 41));
        textBrowser->setStyleSheet(QString::fromUtf8("font: 75 16pt \"MS Shell Dlg 2\";\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 70));\n"
"border-radius: 10px;"));
        Turnover = new QPushButton(centralwidget);
        Turnover->setObjectName(QString::fromUtf8("Turnover"));
        Turnover->setGeometry(QRect(310, 240, 121, 41));
        Turnover->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0.357955 rgba(0, 0, 99, 255), stop:1 rgba(0, 0, 129, 255));\n"
"border-color: black;\n"
"border-radius: 10px;\n"
"color: rgb(255, 255, 255);\n"
"font: 75 10pt \"B Nasim\";"));
        About_us = new QPushButton(centralwidget);
        About_us->setObjectName(QString::fromUtf8("About_us"));
        About_us->setGeometry(QRect(530, 240, 121, 41));
        About_us->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0.357955 rgba(0, 0, 99, 255), stop:1 rgba(0, 0, 129, 255));\n"
"border-color: black;\n"
"border-radius: 10px;\n"
"color: rgb(255, 255, 255);\n"
"font: 75 10pt \"B Nasim\";"));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 753, 21));
        MainWindow->setMenuBar(menubar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Seyed Shop", nullptr));
#ifndef QT_NO_TOOLTIP
        Add_Product->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Adding a new product</p></body></html>", nullptr));
#endif // QT_NO_TOOLTIP
        Add_Product->setText(QApplication::translate("MainWindow", "Add Product", nullptr));
#ifndef QT_NO_TOOLTIP
        Products->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Watching and editing products</p></body></html>", nullptr));
#endif // QT_NO_TOOLTIP
        Products->setText(QApplication::translate("MainWindow", "Products", nullptr));
#ifndef QT_NO_TOOLTIP
        Order->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Ordering</p></body></html>", nullptr));
#endif // QT_NO_TOOLTIP
        Order->setText(QApplication::translate("MainWindow", "Order", nullptr));
#ifndef QT_NO_TOOLTIP
        Orders->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Viewing orders</p></body></html>", nullptr));
#endif // QT_NO_TOOLTIP
        Orders->setText(QApplication::translate("MainWindow", "Orders", nullptr));
        textBrowser->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:16pt; font-weight:72; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-weight:600;\">Welcome to the Seyed Shop</span></p></body></html>", nullptr));
#ifndef QT_NO_TOOLTIP
        Turnover->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Viewing financial turnover</p></body></html>", nullptr));
#endif // QT_NO_TOOLTIP
        Turnover->setText(QApplication::translate("MainWindow", "Turnover", nullptr));
#ifndef QT_NO_TOOLTIP
        About_us->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>a little bit about us</p></body></html>", nullptr));
#endif // QT_NO_TOOLTIP
        About_us->setText(QApplication::translate("MainWindow", "About us", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
