/********************************************************************************
** Form generated from reading UI file 'edit_product.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDIT_PRODUCT_H
#define UI_EDIT_PRODUCT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>

QT_BEGIN_NAMESPACE

class Ui_edit_product
{
public:
    QSpinBox *product_number;
    QPushButton *editing;
    QLabel *label_2;
    QPlainTextEdit *product_price_input;
    QLabel *label_4;
    QLabel *label;
    QLabel *label_3;
    QPlainTextEdit *product_name_input;
    QSpinBox *off_percentage;

    void setupUi(QDialog *edit_product)
    {
        if (edit_product->objectName().isEmpty())
            edit_product->setObjectName(QString::fromUtf8("edit_product"));
        edit_product->resize(400, 300);
        edit_product->setMinimumSize(QSize(400, 300));
        edit_product->setMaximumSize(QSize(400, 300));
        edit_product->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(11, 88, 111, 255), stop:1 rgba(255, 255, 255, 255));"));
        product_number = new QSpinBox(edit_product);
        product_number->setObjectName(QString::fromUtf8("product_number"));
        product_number->setGeometry(QRect(190, 140, 41, 18));
        product_number->setMinimum(1);
        product_number->setSingleStep(1);
        editing = new QPushButton(edit_product);
        editing->setObjectName(QString::fromUtf8("editing"));
        editing->setGeometry(QRect(140, 240, 101, 31));
        editing->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0.357955 rgba(0, 0, 99, 255), stop:1 rgba(0, 0, 129, 255));\n"
"border-color: black;\n"
"border-radius: 10px;\n"
"color: rgb(255, 255, 255);\n"
"font: 75 10pt \"B Nasim\";"));
        label_2 = new QLabel(edit_product);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(70, 90, 96, 29));
        label_2->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 0));"));
        product_price_input = new QPlainTextEdit(edit_product);
        product_price_input->setObjectName(QString::fromUtf8("product_price_input"));
        product_price_input->setGeometry(QRect(180, 90, 101, 31));
        product_price_input->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 97), stop:1 rgba(255, 255, 255, 255));"));
        label_4 = new QLabel(edit_product);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(70, 170, 111, 21));
        label_4->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 0));"));
        label = new QLabel(edit_product);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(70, 50, 99, 29));
        label->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 0));"));
        label_3 = new QLabel(edit_product);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(70, 140, 111, 21));
        label_3->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 0));"));
        product_name_input = new QPlainTextEdit(edit_product);
        product_name_input->setObjectName(QString::fromUtf8("product_name_input"));
        product_name_input->setGeometry(QRect(180, 50, 181, 31));
        product_name_input->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 97), stop:1 rgba(255, 255, 255, 255));"));
        off_percentage = new QSpinBox(edit_product);
        off_percentage->setObjectName(QString::fromUtf8("off_percentage"));
        off_percentage->setGeometry(QRect(190, 170, 41, 18));

        retranslateUi(edit_product);

        QMetaObject::connectSlotsByName(edit_product);
    } // setupUi

    void retranslateUi(QDialog *edit_product)
    {
        edit_product->setWindowTitle(QApplication::translate("edit_product", "Edit product", nullptr));
        editing->setText(QApplication::translate("edit_product", "OK", nullptr));
        label_2->setText(QApplication::translate("edit_product", "<html><head/><body><p align=\"center\"><span style=\" font-size:10pt; font-weight:600;\">product price:  </span></p></body></html>", nullptr));
        product_price_input->setPlainText(QApplication::translate("edit_product", "0", nullptr));
        label_4->setText(QApplication::translate("edit_product", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:600;\">off_percentage: </span></p></body></html>", nullptr));
        label->setText(QApplication::translate("edit_product", "<html><head/><body><p align=\"center\"><span style=\" font-size:10pt; font-weight:600;\">product name: </span></p></body></html>", nullptr));
        label_3->setText(QApplication::translate("edit_product", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:600;\">product number: </span></p></body></html>", nullptr));
        product_name_input->setPlainText(QApplication::translate("edit_product", "product name", nullptr));
    } // retranslateUi

};

namespace Ui {
    class edit_product: public Ui_edit_product {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDIT_PRODUCT_H
