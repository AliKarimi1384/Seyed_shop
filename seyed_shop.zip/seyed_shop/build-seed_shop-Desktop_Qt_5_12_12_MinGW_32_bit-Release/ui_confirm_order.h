/********************************************************************************
** Form generated from reading UI file 'confirm_order.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONFIRM_ORDER_H
#define UI_CONFIRM_ORDER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>

QT_BEGIN_NAMESPACE

class Ui_confirm_order
{
public:
    QLabel *label;
    QPlainTextEdit *cust_name;
    QLabel *label_2;
    QSpinBox *ord_count;
    QPushButton *conf_ord;

    void setupUi(QDialog *confirm_order)
    {
        if (confirm_order->objectName().isEmpty())
            confirm_order->setObjectName(QString::fromUtf8("confirm_order"));
        confirm_order->resize(400, 168);
        confirm_order->setMinimumSize(QSize(400, 168));
        confirm_order->setMaximumSize(QSize(400, 168));
        confirm_order->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(11, 88, 111, 255), stop:1 rgba(255, 255, 255, 255));"));
        label = new QLabel(confirm_order);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 20, 161, 31));
        label->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 0));"));
        cust_name = new QPlainTextEdit(confirm_order);
        cust_name->setObjectName(QString::fromUtf8("cust_name"));
        cust_name->setGeometry(QRect(190, 20, 141, 31));
        cust_name->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 97), stop:1 rgba(255, 255, 255, 255));"));
        label_2 = new QLabel(confirm_order);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(70, 80, 131, 16));
        label_2->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 0));"));
        ord_count = new QSpinBox(confirm_order);
        ord_count->setObjectName(QString::fromUtf8("ord_count"));
        ord_count->setGeometry(QRect(210, 80, 42, 21));
        ord_count->setMinimum(1);
        conf_ord = new QPushButton(confirm_order);
        conf_ord->setObjectName(QString::fromUtf8("conf_ord"));
        conf_ord->setGeometry(QRect(150, 130, 101, 31));
        conf_ord->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0.357955 rgba(0, 0, 99, 255), stop:1 rgba(0, 0, 129, 255));\n"
"border-color: black;\n"
"border-radius: 10px;\n"
"color: rgb(255, 255, 255);\n"
"font: 75 10pt \"B Nasim\";"));

        retranslateUi(confirm_order);

        QMetaObject::connectSlotsByName(confirm_order);
    } // setupUi

    void retranslateUi(QDialog *confirm_order)
    {
        confirm_order->setWindowTitle(QApplication::translate("confirm_order", "Confirm order", nullptr));
        label->setText(QApplication::translate("confirm_order", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:600;\">Enter customer's name:</span></p></body></html>", nullptr));
        cust_name->setPlainText(QApplication::translate("confirm_order", "name", nullptr));
        label_2->setText(QApplication::translate("confirm_order", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:600;\">Enter the count: </span></p></body></html>", nullptr));
#ifndef QT_NO_TOOLTIP
        conf_ord->setToolTip(QApplication::translate("confirm_order", "<html><head/><body><p>editing the product</p></body></html>", nullptr));
#endif // QT_NO_TOOLTIP
        conf_ord->setText(QApplication::translate("confirm_order", "Confirm", nullptr));
    } // retranslateUi

};

namespace Ui {
    class confirm_order: public Ui_confirm_order {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONFIRM_ORDER_H
