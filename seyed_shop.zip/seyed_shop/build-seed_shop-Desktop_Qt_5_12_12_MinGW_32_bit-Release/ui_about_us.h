/********************************************************************************
** Form generated from reading UI file 'about_us.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ABOUT_US_H
#define UI_ABOUT_US_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_about_us
{
public:
    QLabel *label;

    void setupUi(QDialog *about_us)
    {
        if (about_us->objectName().isEmpty())
            about_us->setObjectName(QString::fromUtf8("about_us"));
        about_us->resize(522, 204);
        about_us->setMinimumSize(QSize(522, 204));
        about_us->setMaximumSize(QSize(522, 204));
        about_us->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(11, 88, 111, 255), stop:1 rgba(255, 255, 255, 255));"));
        label = new QLabel(about_us);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 30, 481, 131));
        label->setStyleSheet(QString::fromUtf8("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(255, 255, 255, 97), stop:1 rgba(255, 255, 255, 255));\n"
"border-radius: 10px;"));

        retranslateUi(about_us);

        QMetaObject::connectSlotsByName(about_us);
    } // setupUi

    void retranslateUi(QDialog *about_us)
    {
        about_us->setWindowTitle(QApplication::translate("about_us", "About us", nullptr));
        label->setText(QApplication::translate("about_us", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:600;\">Hello!</span></p><p><span style=\" font-size:10pt; font-weight:600;\">We are a group of three students named Ali Karimi, Ali Jamshid and</span></p><p><span style=\" font-size:10pt; font-weight:600;\">Erfan Jahanbakhsh.</span></p><p><span style=\" font-size:10pt; font-weight:600;\">We made this project for the Advanced programming course,</span></p><p><span style=\" font-size:10pt; font-weight:600;\">under the supervision of dr.Ghiasi.</span></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class about_us: public Ui_about_us {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ABOUT_US_H
