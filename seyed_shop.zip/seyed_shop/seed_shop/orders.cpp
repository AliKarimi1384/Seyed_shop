#include "orders.h"
#include "ui_orders.h"
#include "database.h"
#include "full_receipt.h"
#include <string>

orders::orders(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::orders)
{
    ui->setupUi(this);
    order_db odb;
    ord temp;
    for(int i=0;i<odb.size();i++){
        temp = odb.get_ord(i);
        QListWidgetItem *newItem = new QListWidgetItem;
        newItem->setText(QString::fromStdString(to_string(i+1)+": in "+odb.get_dt(i)+" "+temp.csm_name+" bought "+temp.prd_name));
        ui->products_list->insertItem(i,newItem);
    }
}

orders::~orders()
{
    delete ui;
}

void orders::on_view_receipt_clicked()
{
    full_receipt fl;
    fl.set_index2(ui->products_list->currentIndex().row());
    fl.setModal(true);
    fl.exec();
    close();
}

