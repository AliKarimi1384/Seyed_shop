#include <string>
#include "database.h"
#include "add_product_.h"
#include "ui_add_product_.h"
#include <QMessageBox>
using namespace std;
Add_Product_::Add_Product_(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Add_Product_)
{
    ui->setupUi(this);
}

Add_Product_::~Add_Product_()
{
    delete ui;
}

void Add_Product_::on_pushButton_clicked()
{
    string prd_name = ui->product_name_input->toPlainText().toStdString();
    int price = stoi(ui->product_price_input->toPlainText().toStdString());
    int prd_num = ui->product_number->value();
    int off_per = ui->off_percentage->value();
    product_db *pdb = new product_db();
    pdb->add_product(prd_name,price,prd_num,off_per);
    delete pdb;
    QMessageBox::about(this,"message", "the product successfuly added");
    close();
}

