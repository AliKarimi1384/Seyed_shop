#include "full_receipt.h"
#include "ui_full_receipt.h"
#include "database.h"
#include <string>
#include <fstream>
#include <direct.h>
#include <QMessageBox>
#include <QInputDialog>
#define mkdir _mkdir
int index3;
full_receipt::full_receipt(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::full_receipt)
{
    ui->setupUi(this);
    order_db odb;
    ord obj;
    obj = odb.get_ord(index3);
    ui->date_and_time->setText(QString::fromStdString(odb.get_dt(index3)));
    ui->customer_name->setText(QString::fromStdString(obj.csm_name));
    ui->product_name->setText(QString::fromStdString(obj.prd_name));
    ui->product_price->setText(QString::fromStdString(to_string(obj.price)));
    ui->product_count->setText(QString::fromStdString(to_string(obj.count)));
    ui->off_percentage->setText(QString::fromStdString(to_string(obj.off_per)+'%'));
    ui->tax_amount->setText(QString::fromStdString(to_string(obj.tax)));
    ui->final_price->setText(QString::fromStdString(to_string(obj.fprice)));
}

full_receipt::~full_receipt()
{
    delete ui;
}

void full_receipt::set_index2(int i){
    index3 = i;
}

void full_receipt::on_print_receipt_clicked()
{
    string name = QInputDialog::getText(nullptr, "Name input", "Enter the file name").toStdString();
    if(name == ""){
        QMessageBox::about(this,"Error", "No text entered");
        close();
    } else{
        order_db odb;
        ord obj;
        obj = odb.get_ord(index3);
        mkdir("receipts");
        fstream receipt;
        receipt.open("receipts\\"+name+".txt", ios::out);
        receipt<<"Seyed shop receipt\n"<<"date and time: "<<odb.get_dt(index3)<<"customer name: "
              <<obj.csm_name<<"\nproduct name: "<<obj.prd_name<<"\nproduct price: "<<to_string(obj.price)
             <<"\nproduct count: "<<to_string(obj.count)<<"\noff percentage: "<<to_string(obj.off_per)
            <<"%\ntax rate: 10%\ntax amount: "<<to_string(obj.tax)<<"\nfinal price: "<<to_string(obj.fprice);
        receipt.close();
        QMessageBox::about(this,"Message", "The receipt successfully saved in the receipts directory as a text file.");
        close();
    }
}

