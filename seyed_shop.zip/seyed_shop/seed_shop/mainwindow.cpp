#include "mainwindow.h"
#include <QMessageBox>
#include "ui_mainwindow.h"
#include "add_product_.h"
#include "products_.h"
#include "order.h"
#include "orders.h"
#include "database.h"
#include "about_us.h"
#include "first_page.h"
#include<ctime>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    first_page fp;
    fp.setModal(true);
    fp.exec();
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_Add_Product_clicked()
{
    Add_Product_ add_product_;
    add_product_.setModal(true);
    add_product_.exec();
}


void MainWindow::on_Products_clicked()
{
    products_ products;
    products.setModal(true);
    products.exec();
}


void MainWindow::on_Order_clicked()
{
    order _order;
    _order.setModal(true);
    _order.exec();
}


void MainWindow::on_Orders_clicked()
{
    orders _orders;
    _orders.setModal(true);
    _orders.exec();
}


void MainWindow::on_Turnover_clicked()
{
    order_db odb;
    ord temp;
    int trn = 0;
    int tm = time(0);
    for(int i=0;i<odb.size();i++){
        temp = odb.get_ord(i);
        //checking the order date
        if(tm - temp.timestamp <= 2592000)//1 month is 2592000 seconds
        {
            trn += temp.fprice;
        }else{
            break;
        }
    }
    QMessageBox::about(this,"Financial turnover", QString::fromStdString("Your financial turnover in the last month is "+to_string(trn)+"$."));
}


void MainWindow::on_About_us_clicked()
{
    about_us abt;
    abt.setModal(true);
    abt.exec();
}

