#ifndef ADD_PRODUCT__H
#define ADD_PRODUCT__H

#include <QDialog>

namespace Ui {
class Add_Product_;
}

class Add_Product_ : public QDialog
{
    Q_OBJECT

public:
    explicit Add_Product_(QWidget *parent = nullptr);
    ~Add_Product_();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Add_Product_ *ui;
};

#endif // ADD_PRODUCT__H
