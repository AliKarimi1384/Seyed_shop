#ifndef PRODUCTS__H
#define PRODUCTS__H

#include <QDialog>

namespace Ui {
class products_;
}

class products_ : public QDialog
{
    Q_OBJECT

public:
    explicit products_(QWidget *parent = nullptr);
    ~products_();

private slots:

    void on_edit_product_clicked();

    void on_delete_product_clicked();

private:
    Ui::products_ *ui;
};

#endif // PRODUCTS__H
