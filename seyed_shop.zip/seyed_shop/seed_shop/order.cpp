#include "order.h"
#include "ui_order.h"
#include <string>
#include "database.h"
#include "confirm_order.h"

order::order(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::order)
{
    ui->setupUi(this);
    product_db pdb;
    prd temp;
    for(int i=0;i<pdb.size();i++){
        temp = pdb.get_prd(i);
        QListWidgetItem *newItem = new QListWidgetItem;
        newItem->setText(QString::fromStdString(to_string(i+1)+": "+temp.name+" - "+to_string(temp.price)+" $ - "+to_string(temp.num)+" left - "+to_string(temp.off)+"% off"));
        ui->products_list->insertItem(i,newItem);
    }
}

order::~order()
{
    delete ui;
}

void order::on_order_ok_clicked()
{
    confirm_order cno;
    cno.setModal(true);
    cno.set_index(ui->products_list->currentIndex().row());
    cno.exec();
    close();
}

