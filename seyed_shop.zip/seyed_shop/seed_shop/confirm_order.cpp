#include "confirm_order.h"
#include "ui_confirm_order.h"
#include <string>
#include "database.h"
#include <ctime>
#include <QMessageBox>
confirm_order::confirm_order(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::confirm_order)
{
    ui->setupUi(this);
}

confirm_order::~confirm_order()
{
    delete ui;
}
int index2;
void confirm_order::set_index(int i){
    index2 = i;
}

void confirm_order::on_conf_ord_clicked()
{
    product_db pdb;
    prd temp = pdb.get_prd(index2);
    string csm_name = ui->cust_name->toPlainText().toStdString();
    int count = ui->ord_count->value();
    if(count > temp.num){
        QMessageBox::about(this,"Error", "The count is more than supply.");
        close();
    } else{
        int tax = temp.price * count * 0.1 * (1.0 - (temp.off/100.0));
        int final_price = temp.price * count * (1.0 - (temp.off/100.0)) + tax;
        order_db odb;
        odb.add_order(csm_name,temp.name,time(0),temp.price,count,temp.off,tax,final_price);
        if(temp.num - count == 0){
            pdb.delete_product(index2);
        } else{
            pdb.reduce_num(index2,count);
        }
        QMessageBox::about(this,"Message", "The order seccussfully confirmed.");
        close();
    }
}

