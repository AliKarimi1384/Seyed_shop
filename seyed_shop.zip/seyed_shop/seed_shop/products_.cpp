#include "products_.h"
#include "ui_products_.h"
#include "database.h"
#include "edit_product.h"
#include <QMessageBox>
#include <string>

products_::products_(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::products_)
{
    ui->setupUi(this);
    product_db pdb;
    prd temp;
    for(int i=0;i<pdb.size();i++){
        temp = pdb.get_prd(i);
        QListWidgetItem *newItem = new QListWidgetItem;
        newItem->setText(QString::fromStdString(to_string(i+1)+": "+temp.name+" - "+to_string(temp.price)+" $ - "+to_string(temp.num)+" left - "+to_string(temp.off)+"% off"));
        ui->products_list->insertItem(i,newItem);
    }

}

products_::~products_()
{
    delete ui;
}

void products_::on_edit_product_clicked()
{
    edit_product edit_product;
    edit_product.setModal(true);
    edit_product.set_index(ui->products_list->currentIndex().row());
    edit_product.exec();
    close();
}


void products_::on_delete_product_clicked()
{
    product_db pdb;
    pdb.delete_product(ui->products_list->currentIndex().row());
    QMessageBox::about(this,"message", "the product successfuly deleted");
    close();
}

