#include "edit_product.h"
#include "ui_edit_product.h"
#include <string>
#include "database.h"
#include <QMessageBox>
int index;
edit_product::edit_product(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::edit_product)
{
    ui->setupUi(this);
}

edit_product::~edit_product()
{
    delete ui;
}
void edit_product::set_index(int i){
    index = i;
}
void edit_product::on_editing_clicked()
{
    string prd_name = ui->product_name_input->toPlainText().toStdString();
    int price = stoi(ui->product_price_input->toPlainText().toStdString());
    int prd_num = ui->product_number->value();
    int off_per = ui->off_percentage->value();
    product_db *pdb = new product_db();
    pdb->change_product(index,prd_name,price,prd_num,off_per);
    delete pdb;
    QMessageBox::about(this,"message", "the product successfuly edited");
    close();
}

