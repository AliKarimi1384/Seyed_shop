#include "first_page.h"
#include "ui_first_page.h"
#include <QMessageBox>
first_page::first_page(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::first_page)
{
    ui->setupUi(this);
}
bool flag = true;
first_page::~first_page()
{
    if(flag){
        exit(0);
    }
    delete ui;

}
int pass[4] = {1,2,3,4};
void first_page::on_enter_pass_clicked()
{
    int pass1 = ui->pass_1->value();
    int pass2 = ui->pass_2->value();
    int pass3 = ui->pass_3->value();
    int pass4 = ui->pass_4->value();
    if(pass[0] = pass1 && pass[1] == pass2 && pass[2] == pass3 && pass[3] == pass4){
        flag = false;
        close();
    } else{
        QMessageBox::about(this,"Error", "The password is incorrect");
        exit(0);
    }
}

