#ifndef FULL_RECEIPT_H
#define FULL_RECEIPT_H

#include <QDialog>

namespace Ui {
class full_receipt;
}

class full_receipt : public QDialog
{
    Q_OBJECT

public:
    explicit full_receipt(QWidget *parent = nullptr);
    ~full_receipt();
    void set_index2(int i);
private slots:
    void on_print_receipt_clicked();

private:
    Ui::full_receipt *ui;
};

#endif // FULL_RECEIPT_H
