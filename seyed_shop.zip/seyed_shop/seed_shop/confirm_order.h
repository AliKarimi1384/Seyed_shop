#ifndef CONFIRM_ORDER_H
#define CONFIRM_ORDER_H

#include <QDialog>

namespace Ui {
class confirm_order;
}

class confirm_order : public QDialog
{
    Q_OBJECT

public:
    explicit confirm_order(QWidget *parent = nullptr);
    ~confirm_order();
    void set_index(int i);

private slots:
    void on_conf_ord_clicked();

private:
    Ui::confirm_order *ui;
};

#endif // CONFIRM_ORDER_H
