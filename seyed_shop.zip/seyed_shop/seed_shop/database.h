#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <ctime>
#include <direct.h>
#define mkdir _mkdir
using namespace std;
struct prd
{
    string name;
    int price;
    int num;
    int off;
};
class product_db
{
public:
    product_db()
    {
        mkdir("databases");
        file.open("databases\\product_db.csv", ios::in);
        string temp;
        while (!file.eof())
        {
            prd tmp;
            getline(file, temp);
            if (temp[0] == '\0')
            {
                break;
            }
            int start = 0;
            string temp2 = "";
            while (temp[start] != ',' && temp[start] != '\0')
            {
                temp2 += temp[start];
                ++start;
            }
            tmp.name = temp2;
            temp2 = "";
            ++start;
            while (temp[start] != ',' && temp[start] != '\0')
            {
                temp2 += temp[start];
                ++start;
            }
            tmp.price = stoi(temp2);
            temp2 = "";
            ++start;
            while (temp[start] != ',' && temp[start] != '\0')
            {
                temp2 += temp[start];
                ++start;
            }
            tmp.num = stoi(temp2);
            temp2 = "";
            ++start;
            while (temp[start] != ',' && temp[start] != '\0')
            {
                temp2 += temp[start];
                ++start;
            }
            tmp.off = stoi(temp2);
            vec.push_back(tmp);
        }
        file.close();
    }
    void add_product(string _name, int _price, int _num, int _off)
    {
        prd temp;
        temp.name = _name;
        temp.price = _price;
        temp.num = _num;
        temp.off = _off;
        vec.push_back(temp);
    }
    void change_product(int index, string _name, int _price, int _num, int _off)
    {
        prd temp;
        temp.name = _name;
        temp.price = _price;
        temp.num = _num;
        temp.off = _off;
        vec[index] = temp;
    }
    void delete_product(int index)
    {
        vec.erase(vec.begin() + index);
    }
    const int size()
    {
        return vec.size();
    }
    const prd get_prd(int index)
    {
        return vec[index];
    }
    void reduce_num(int index, int num)
    {
        vec[index].num -= num;
    }
    ~product_db()
    {
        // I know the second mkdir is useless but I want to be sure
        mkdir("databases");
        fstream fl;
        fl.open("databases\\product_db.csv", ios::out);
        string temp = "";
        prd tmp;
        for (int i = 0; i < vec.size(); i++)
        {
            tmp = vec[i];
            temp += tmp.name + ',' + to_string(tmp.price) + ',' + to_string(tmp.num) + ',' + to_string(tmp.off) + '\n';
        }
        fl << temp;
        fl.close();
    }

private:
    fstream file;
    vector<prd> vec;
};
struct ord
{
    // customer name
    string csm_name;
    string prd_name;
    int timestamp;
    int price;
    int count;
    int off_per;
    // tax rate always is 10%
    int tax;
    // final price
    int fprice;
};
class order_db
{
public:
    order_db()
    {
        mkdir("databases");
        file.open("databases\\order_db.csv", ios::in);
        string temp;
        while (!file.eof())
        {
            ord tmp;
            getline(file, temp);
            if (temp[0] == '\0')
            {
                break;
            }
            int start = 0;
            string temp2 = "";
            while (temp[start] != ',' && temp[start] != '\0')
            {
                temp2 += temp[start];
                ++start;
            }
            tmp.csm_name = temp2;
            temp2 = "";
            ++start;
            while (temp[start] != ',' && temp[start] != '\0')
            {
                temp2 += temp[start];
                ++start;
            }
            tmp.prd_name = temp2;
            temp2 = "";
            ++start;
            while (temp[start] != ',' && temp[start] != '\0')
            {
                temp2 += temp[start];
                ++start;
            }
            tmp.timestamp = stoi(temp2);
            temp2 = "";
            ++start;
            while (temp[start] != ',' && temp[start] != '\0')
            {
                temp2 += temp[start];
                ++start;
            }
            tmp.price = stoi(temp2);
            temp2 = "";
            ++start;
            while (temp[start] != ',' && temp[start] != '\0')
            {
                temp2 += temp[start];
                ++start;
            }
            tmp.count = stoi(temp2);
            temp2 = "";
            ++start;
            while (temp[start] != ',' && temp[start] != '\0')
            {
                temp2 += temp[start];
                ++start;
            }
            tmp.off_per = stoi(temp2);
            temp2 = "";
            ++start;
            while (temp[start] != ',' && temp[start] != '\0')
            {
                temp2 += temp[start];
                ++start;
            }
            tmp.tax = stoi(temp2);
            temp2 = "";
            ++start;
            while (temp[start] != ',' && temp[start] != '\0')
            {
                temp2 += temp[start];
                ++start;
            }
            tmp.fprice = stoi(temp2);
            vec.push_back(tmp);
        }
        file.close();
    }
    void add_order(string _csm_name, string _prd_name, int _timestamp, int _price, int _count, int _off_per, int _tax, int _fprice)
    {
        ord temp;
        temp.csm_name = _csm_name;
        temp.prd_name = _prd_name;
        temp.timestamp = _timestamp;
        temp.price = _price;
        temp.count = _count;
        temp.off_per = _off_per;
        temp.tax = _tax;
        temp.fprice = _fprice;
        vec.push_back(temp);
    }
    const int size()
    {
        return vec.size();
    }
    const ord get_ord(int index)
    {
        return vec[index];
    }
    string get_dt(int index)
    {
        time_t dt = vec[index].timestamp;
        string date_time = ctime(&dt);
        return date_time;
    }
    ~order_db()
    {
        mkdir("databases");
        fstream fl;
        fl.open("databases\\order_db.csv", ios::out);
        string temp = "";
        ord tmp;
        for (int i = 0; i < vec.size(); i++)
        {
            tmp = vec[i];
            temp += tmp.csm_name + ',' + tmp.prd_name + ',' + to_string(tmp.timestamp) + ',' + to_string(tmp.price) + ',' + to_string(tmp.count) + ',' + to_string(tmp.off_per) + ',' + to_string(tmp.tax) + ',' + to_string(tmp.fprice) + '\n';
        }
        fl << temp;
        fl.close();
    }

private:
    fstream file;
    vector<ord> vec;
};
