#ifndef EDIT_PRODUCT_H
#define EDIT_PRODUCT_H

#include <QDialog>

namespace Ui {
class edit_product;
}

class edit_product : public QDialog
{
    Q_OBJECT

public:
    explicit edit_product(QWidget *parent = nullptr);
    void set_index(int i);
    ~edit_product();

private slots:
    void on_editing_clicked();

private:
    Ui::edit_product *ui;
};

#endif // EDIT_PRODUCT_H
